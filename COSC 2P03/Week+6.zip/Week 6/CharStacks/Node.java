package CharStacks;


import java.io.*;


/** This class represents a node containing a character in a linked structure.
  *
  * @author  D. Hughes
  *
  * @version  1.0 (Jan. 2014)                                                    */

class Node implements Serializable {
    
    
    char  item;  // the item in the node
    Node  next;  // the next node in the structure
    
    
    /** This constructor creates a new node for the linked structure representing
      * the stack.
      *
      * @param  i  the item in the node.
      * @param  n  the next node in the structure.                               */
    
    public Node ( char i, Node n ) {
        
        item = i;
        next = n;
        
    }; // constructor
    
    
} // Node