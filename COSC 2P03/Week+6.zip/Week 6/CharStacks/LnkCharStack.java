package CharStacks;


import java.io.*;


/** This class represents an implementation of the CharStack interface using a
  * sequentially-linked structure. It makes use of the class Node to represent
  * the list nodes.
  *
  * @see  CharStack
  * @see  Node
  * @see  UnderflowException
  *
  * @author  D. Hughes
  *
  * @version  1.0 (Jan. 2014)
  *
  * new concepts: linked implementation of a stack                               */

public class LnkCharStack implements CharStack, Serializable {
    
    
    private Node  top;  // top element of the stack
    
    
    /** This constructor creates a new, empty stack.                             */
    
    public LnkCharStack ( ) {
        
        top = null;
        
    }; // constructor
    
    
    /** This method adds an item to the stack. Stack overflow occurs if there is no
      * room to add another item.
      *
      * @param  item  the item (char) to be added.
      *
      * @throws  OutOfMemoryError  no more room to add to stack.                 */
    
    public void push ( char item ) {
        
        top = new Node(item,top);
        
    }; // push
    
    
    /** This method removes an item to the stack. Stack underflow occurs if there
      * are no more items left.
      *
      * @return  char  the item (char) removed.
      *
      * @throws  UnderflowException  no items available in stack.                */
    
    public char pop ( ) {
        
        char  i;
        
        if ( top == null ) {
            throw new UnderflowException();
        }
        else {
            i = top.item;
            top = top.next;
            return i;
        }
        
    }; // pop
    
    
    /** This method returns the top item of the stack. Stack underflow occurs if
      * there are no more items left.
      *
      * @return  char  the top item (char).
      *
      * @throws  UnderflowException  no items available in stack.                */
    
    public char top ( ) {
        
        if ( top == null ) {
            throw new UnderflowException();
        }
        else {
            return top.item;
        }
        
    }; // top
    
    
    /** This method returns true if the stack contains no items.
      *
      * @return  boolean  whether the stack is empty.                            */
    
    public boolean empty ( ) {
        
        return top == null;
        
    }; // empty
    
    
} // LnkCharStack