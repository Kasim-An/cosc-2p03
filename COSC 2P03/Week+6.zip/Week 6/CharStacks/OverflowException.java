package CharStacks;


/** This class represents the exception occurring when an attempt is made to add an
  * item to a stack and there is no space available to hold the item.
  *
  * @author  D. Hughes
  *
  * @version  1.0 (Jan. 2014)                                                    */

public class OverflowException extends RuntimeException { }
