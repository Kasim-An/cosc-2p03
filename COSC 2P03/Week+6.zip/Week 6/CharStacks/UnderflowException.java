package CharStacks;


/** This class represents the exception occurring when an attempt is made to remove
  * or view an item from an empty stack.
  *
  * @author  D. Hughes
  *
  * @version  1.0 (Jan. 2014)                                                    */

public class UnderflowException extends RuntimeException { }