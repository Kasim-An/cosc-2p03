package CharStacks;


/** This interface defines the abstract data type stack representing a LIFO
  * collection of characters.
  *
  * @see  OverflowException
  * @see  UnderflowException
  *
  * @author  D. Hughes
  *
  * @version  1.0 (Jan. 2014)
  *
  * new concepts: stack                                                          */

public interface CharStack {
    
    
    /** This method adds an item to the stack. Stack overflow occurs if there is no
      * room to add another item.
      *
      * @param  item  the item (char) to be added.
      *
      * @throws  OverflowException  no more room to add to stack.                */
    
    public void push ( char item );
    
    
    /** This method removes an item to the stack. Stack underflow occurs if there
      * are no more items left.
      *
      * @return  char  the item (char) removed.
      *
      * @throws  UnderflowException  no items available in stack.                */
    
    public char pop ( );
    
    
    /** This method returns the top item of the stack. Stack underflow occurs if
      * there are no more items left.
      *
      * @return  char  the top item (char).
      *
      * @throws  UnderflowException  no items available in stack.                */
    
    public char top ( );
    
    
    /** This method returns true if the stack contains no items.
      *
      * @return  boolean  whether the stack is empty.                            */
    
    public boolean empty ( );
    
    
} // CharStack