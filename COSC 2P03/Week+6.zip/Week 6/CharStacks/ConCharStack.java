package CharStacks;


import java.io.*;


/** This class represents an implementation of the CharStack interface using
  * contiguous memory (i.e. an array).
  *
  * @see  CharStack
  * @see  OverflowException
  * @see  UnderflowException
  *
  * @author  D. Hughes
  *
  * @version  1.0 (Jan. 2014)
  *
  * new concepts: array implementation of stack                                  */

public class ConCharStack implements CharStack, Serializable {
    
    
    private int     top;   // next available element
    private char[]  elts;  // elements of the stack
    
    
    /** This constructor creates a new, empty stack capable of holding 100 items */
    
    public ConCharStack ( ) {
        
        this(100);
        
    }; // constructor
    
    
    /** This constructor creates a new, empty stack capable of holding a particular
      * number of items.
      *
      * @param  size  the number of items for the stack.                         */
    
    public ConCharStack ( int size ) {
        
        elts = new char[size];
        top = 0;
        
    }; // constructor
    
    
    /** This method adds an item to the stack. Stack overflow occurs if there is no
      * room to add another item.
      *
      * @param  item  the item (char) to be added.
      *
      * @throws  OverflowException  no more room to add to stack.                */
    
    public void push ( char item ) {
        
        if ( top >= elts.length ) {
            throw new OverflowException();
        }
        else {
            elts[top] = item;
            top = top + 1;
        };
        
    }; // push
    
    
    /** This method removes an item to the stack. Stack underflow occurs if there
      * are no more items left.
      *
      * @return  char  the item (char) removed.
      *
      * @throws  UnderflowException  no items available in stack.                */
    
    public char pop ( ) {
        
        if ( top <= 0 ) {
            throw new UnderflowException();
        }
        else {
            top = top - 1;
            return elts[top];
        }
        
    }; // pop
    
    
    /** This method returns the top item of the stack. Stack underflow occurs if
      * there are no more items left.
      *
      * @return  char  the top item (char).
      *
      * @throws  UnderflowException  no items available in stack.                */
    
    public char top ( ) {
        
        if ( top <= 0 ) {
            throw new UnderflowException();
        }
        else {
            return elts[top-1];
        }
        
    }; // top
    
    
    /** This method returns true if the stack contains no items.
      *
      * @return  boolean  whether the stack is empty.                            */
    
    public boolean empty ( ) {
        
        return top <= 0;
        
    }; // empty
    
    
} // ConCharStack