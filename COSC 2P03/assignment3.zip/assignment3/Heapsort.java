package assignment3;
public class Heapsort{
   
  static int leftChild(int i){
        return 2*i + 1;
    }

public int[] heapsort(int[] a){
        for(int i = a.length/2; i >= 0; i--)
            help(a, i, a.length);
        for(int j = a.length - 1; j > 0; j--){
            int tmp = a[0];
            a[0] = a[j];
            a[j] = tmp;
            help(a, 0, j);
        }
        return a;
    }
   public void help(int[] a, int i, int n){
        int child;
        int tmp;
        for(tmp = a[i]; leftChild(i) < n; i = child){
            child = leftChild(i);
            if(child != n -1 && a[child]<(a[child + 1]))
                child++;
            if(tmp<a[child])
                a[i] = a[child];
            else
                break;
        }
        a[i] = tmp;
    }
}