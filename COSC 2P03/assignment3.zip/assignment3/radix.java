package assignment3;
public class Radixsort{
  public Radixsort(int[] number,int a){//LSD
  int [][]place = new int [10][number.length];
  int[]order=new int[10];
  int maxa=1;
  while(a<maxa){
    for(int i=0;i<number.length;i++)
    {
      int lsd=((number[i]/n)%10);
      place[lsd][order[lsd]]=number[i];
      order[lsd]++;
    }
    for(int i=0;i<10;i++)
    {
      if(order[i] != 0)
        for(intj = 0; j < order[i]; j++)
      {
        number[k] = temp[i][j];
        k++;
      }
      order[i] = 0;
    }
    n=n* 10;
    k = 0;
    maxa++;
  }
}
}