package assignment3;
public class Insertionsort {
    public static int[] insertionsort(int[] a) {
        for (int i = 1; i < a.length; i++) {
            int b = a[i];
            int j;
            for (j = i; j > 0 && b<(a[j-1]); j--){
              a[j] = a[j - 1];
            }
            a[j] = b;
        }
        return a;
    }
}