public class Sorter{
  public Sorter(int []array){
    public int heapsort{
      return Heapsort(array)}
  }}