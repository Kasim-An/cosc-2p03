package Rental;


import BasicIO.*;
import static BasicIO.Formats.*;


public class Rental {
    
    
    private Node            avail;    // list of available cars
    private Node            rented;   // list of rented cars
    private ASCIIDisplayer  display;  // for display of lists
    private BasicForm       form;     // for user interaction
    
    
    public Rental ( ) {
        
        int  button;  // button pressed
        
        display = new ASCIIDisplayer();
        form = new BasicForm("Rent","Return","List","Quit");
        avail = null;
        rented = null;
        loadCars();
        for ( ; ; ) {
            button = form.accept();
        if ( button == 3 ) break;  // Quit
            switch ( button ) {
                case 0: {          // Rent
                    doRent();
                    break;
                }
                case 1: {          // Return
                    doReturn();
                    break;
                }
                case 2: {          // List
                    doList();
                    break;
                }
            };
        };
        form.close();
        display.close();
        
    }; // constructor
    
    
    private void doRent ( ) {
        
        Car  aCar;  // car to be rented
        
        aCar = removeAvail();
        if ( aCar == null ) {
            display.writeString("No cars available");
        }
        else {
            addRented(aCar);
            display.writeString("Rented: "+aCar.getLicence());
        };
        display.newLine();
        
    };  // doRent
    
    
    private void doReturn ( ) {
        
        Car     aCar;     // car being returned
        
        aCar = removeRented();
        if ( aCar == null ) {
            display.writeString("No cars currently rented");
        }
        else {
            addAvail(aCar);
            display.writeString("Returned: "+aCar.getLicence());
        };
        display.newLine();
        
    };  // doReturn
    
    
    private void doList ( ) {
        
        display.writeLine("Available");
        listAvail();
        display.writeLine("Rented");
        listRented();
        
    };  // doList
    
    
    private void loadCars ( ) {
        
        ASCIIDataFile  carFile;  // file of car info
        Car            aCar;
        
        carFile = new ASCIIDataFile();
        for ( ; ; ) {
            aCar = new Car(carFile);
        if ( carFile.isEOF() ) break;
            addAvail(aCar);
        };
        
    };  // loadCars
    
    
    private void addAvail ( Car aCar ) {
        
        avail = new Node(aCar,avail);
        
    };  // addAvail
    
    
    private Car removeAvail ( ) {
        
        Car  result;  // car to be rented
        
        if ( avail == null ) {
            result = null;
        }
        else {
            result = avail.item;
            avail = avail.next;
        };
        return result;
        
    };  // removeAvail;
    
    
    private void listAvail ( ) {
        
        Node  p;
        
        p = avail;
        while ( p != null ) {
            display.writeString(p.item.getLicence());
            display.writeInt(p.item.getMileage());
            display.writeInt(p.item.getCategory());
            display.newLine();
            p = p.next;
        };
        display.newLine();

    };  // listAvail
    
    
    private void addRented ( Car aCar ) {
        
        rented = new Node(aCar,rented);
        
    };  // addRented
    
    
    private Car removeRented ( ) {
        
        Car  result;  // car to be rented
        
        if ( rented == null ) {
            result = null;
        }
        else {
            result = rented.item;
            rented = rented.next;
        };
        return result;
        
    }; // removeRented
    
    
    private void listRented ( ) {
        
        Node  p;
        
        p = rented;
        while ( p != null ) {
            display.writeString(p.item.getLicence());
            display.writeInt(p.item.getMileage());
            display.writeInt(p.item.getCategory());
            display.newLine();
            p = p.next;
        };
        display.newLine();
        
    };  // listRented
    
    
    public static void main ( String[] args ) { Rental r = new Rental(); };
    
    
}  // Rental