package FSM;


import BasicIO.*;


public class FSM {
    
    
    private static final int  ERROR = -1;
    
    private int [][]   transTable;  // state transition table
    private boolean[]  finalState;  // state is a final state
    private int        curState;    // current state
    
    
    public FSM ( ASCIIDataFile in ) {
        
        char  a;   // symbol
        int   s;   // state
        int   sp;  // new state
        int   n;   // number of states
        
        n = in.readInt();
        transTable = new int[128][n];
        finalState = new boolean[n];
        for ( int i=0 ; i<transTable.length ; i++ ) {
            for ( int j=0 ; j<transTable[i].length ; j++ ) {
                transTable[i][j] = ERROR;
            };
        };
        for ( int i=0 ; i<finalState.length ; i++ ) {
            a = in.readChar();
            finalState[i] = Character.toUpperCase(a)=='F';
        };
        for ( ; ; ) {
            s = in.readInt();
        if ( in.isEOF() ) break;
            a = in.readChar();
            sp = in.readInt();
            transTable[a][s] = sp;
        };
        curState = 0;
        
    };  // constructor
    
    
    public String toString ( ) {
        
        String result;
        
        result = "";
        for ( char a=0 ; a<transTable.length ; a++ ) {
            result = result + a + ": ";
            for ( int s=0 ; s<transTable[a].length ; s++ ) {
                result = result + " " + transTable[a][s];
            };
            result = result + "\n";
        };
        return result;
        
    };  // toString
    
    
    public boolean recognize ( String aString ) {
        
        char[]  expr;  // string as array
        int     i;
        
        curState = 0;
        expr = aString.toCharArray();
        i = 0;
        while ( curState!=ERROR & i<expr.length ) {
            curState = transTable[expr[i]][curState];
            i = i + 1;
        };
        if ( i==expr.length & curState != ERROR ) {
            return finalState[curState];
        }
        else {
            return false;
        }
        
    };  // recognize
    
    
}  // FSM