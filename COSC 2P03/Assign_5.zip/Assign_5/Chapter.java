package Assign_5;

/* StudentName: Jiachao Wu  
 * 
 * Student Number:5726922
 * 
 * Date:2016/4/4  */

 public interface Chapter {
   
   
   public String getSerialNum();
   

   public String getChapAuthor();
  
   public int getNumChapter();
   
   public String getChapTitle();


   public int getPages();
   
   public double getRoyalty();
     
     
   public double calCost();

}