package Collections;

import java.io.*;
import java.util.*;


/** This class represents an implementation of the List interface using a
  * sequentially-linked structure.
  *
  * @see  List
  * @see  Keyed
  * @see  NoSpaceException
  * @see  NoItemException
  *
  * @author  D. Hughes
  *
  * @version  1.0 (Jan. 2014)
  *
  * new concepts: linkled implementation of a cursored list                      */

public class LnkList < E > implements List<E>, Serializable {
    
    
    Node<E>  front;   // the list header
    Node<E>  cursor;  // the list cursor
    Node<E>  pred;    // the node before the cursor
    int      length;  // the length of the list
    
    
    /** This constructor creates a new empty list.                               */
    
    public LnkList ( ) {
        
        front = new Node<E>(null,null);
        cursor = null;
        pred = front;
        length = 0;
        
    }; // constructor
    
    
    /** This method adds an item to the list in front of the cursor. If the cursor
      * is off the end of the list, the insertion is at the end of the list. The
      * cursor references the item just added. ListOverflow occurs if there is no
      * room to add another item.
      *
      * @param  item  the item to be added.
      *
      * @exception  OutOfMemoryError  no more room to add items.                 */
    
    public void add ( E i ) {
        
        pred.next = new Node<E>(i,cursor);
        cursor = pred.next;
        length = length + 1;
        
    }; // add
    
    
    /** This method removes the item at the cursor from the list. The cursor
      * references the item following the one removed. A NoItemException occurs if
      * the cursor was off the end of the list.
      *
      * @result  E  the item removed.
      *
      * @exception  NoItemException  no current item (cursor off list).          */
    
    public E remove ( ) {
        
        E  i;
        
        if ( cursor == null ) {
            throw new NoItemException();
        }
        else {
            i = cursor.item;
            cursor = cursor.next;
            pred.next = cursor;
            length = length - 1;
            return i;
        }
        
    }; // remove
    
    
    /** This method returns the item at the cursor. A NoItemException occurs if the
      * cursor was off the end of the list.
      *
      * @result  E  the item at the cursor.
      *
      * @exception  NoItemException  no current item (cursor off list).          */
    
    public E get ( ) {
        
        if ( cursor == null ) {
            throw new NoItemException();
        }
        else {
            return cursor.item;
        }
        
    }; // get
    
    
    /** This method returns true if the list has no items.
      *
      * @return  boolean  the list has no items.                                 */
    
    public boolean empty ( ) {
        
        return length == 0;
        
    }; // empty
    
    
    /** This method returns the number of items in the list.
      *
      * @result  int  the number of items in the list.                           */
    
    public int length ( ) {
        
        return length;
        
    }; // length
    
    
    /** This method moves the cursor to the first item on the list. If the list is
      * empty, the cursor will be off the end of the list.                       */
    
    public void toFront ( ) {
        
        pred = front;
        cursor = pred.next;
        
    }; // toFront
    
    
    /** This method advances the cursor to the next item in the list. If the cursor
      * was off the list, it remains off the list.                               */
    
    public void advance( ) {
        
        if ( cursor != null ) {
            pred = cursor;
            cursor = cursor.next;
        };
        
    }; // advance
    
    
    /** This method indicates if the cursor is off the end of the list.
      *
      * @return  boolean  the cursor is off the end of the list.                 */
    
    public boolean offEnd ( ) {
        
        return cursor == null;
        
    }; // offEnd
    
    
} // LnkList