package Rental;


import BasicIO.*;
import Collections.*;
import static BasicIO.Formats.*;


public class Rental {
    
    
    private List<Car>  avail;   // list of available cars
    private List<Car>  rented;  // list of rented cars
    private ASCIIDisplayer  display;  // for display of lists
    private BasicForm  form;    // form for user interaction
    
    
    public Rental ( ) {
        
        int  button;  // button pressed
        
        display = new ASCIIDisplayer();
        form = new BasicForm("Rent","Return","List","Quit");
        avail = new LnkList<Car>();
        rented = new LnkList<Car>();
        loadCars();
        setupForm();
        for ( ; ; ) {
            form.clearAll();
            button = form.accept();
        if ( button == 3 ) break;  // Quit
            switch ( button ) {
                case 0: {          // Rent
                    doRent();
                    break;
                }
                case 1: {          // Return
                    doReturn();
                    break;
                }
                case 2: {          // List
                    doList();
                    break;
                }
            };
            form.accept("OK");
        };
        form.close();
        display.close();
        
    }; // constructor
    
    
    private void doRent ( ) {
        
        int  cat;   // rental category
        Car  aCar;  // car to be rented
        
        cat = form.readInt("cat");
        aCar = removeAvail(cat);
        if ( aCar == null ) {
            form.writeString("msg","No cars available in that category");
        }
        else {
            fillForm(aCar);
            addRented(aCar);
            form.writeString("msg","Rented: "+aCar.getLicence());
        }
        
    };  // doRent
    
    
    private void doReturn ( ) {
        
        String  licence;  // licence plate
        Car     aCar;     // car being returned
        int     mileage;  // mileage at return
        double  cost;     // cost of rental
        
        licence = form.readString("licence");
        aCar = removeRented(licence);
        if ( aCar == null ) {
            form.writeString("msg","Licence: "+licence+" is not currently rented");
        }
        else {
            fillForm(aCar);
            form.accept("OK");
            mileage = form.readInt("nMileage");
            cost = aCar.returned(mileage);
            form.writeDouble("amt",cost);
            addAvail(aCar);
            form.writeString("msg","Returned: "+aCar.getLicence());
        };
        
    };  // doReturn
    
    
    private void doList ( ) {
        
        display.writeLine("Available");
        listAvail();
        display.writeLine("Rented");
        listRented();
        form.writeString("msg","Listed");
        
    };  // doList
    
    
    private void loadCars ( ) {
        
        ASCIIDataFile  carFile;  // file of car info
        Car            aCar;
        
        carFile = new ASCIIDataFile();
        for ( ; ; ) {
            aCar = new Car(carFile);
        if ( carFile.isEOF() ) break;
            addAvail(aCar);
        };
        
    };  // loadCars
    
    
    private void setupForm ( ) {
        
        form.setTitle("Acme Rentals");
        form.addTextField("licence","Licence",8,10,10);
        form.addRadioButtons("cat","Category",true,10,40,Car.CATEGORIES);
        form.addTextField("rate","Rate",getCurrencyInstance(),8,294,40);
        form.setEditable("rate",false);
        form.addTextField("oMileage","Rental Mileage",getIntegerInstance(),
                          8,10,160);
        form.setEditable("oMileage",false);
        form.addTextField("nMileage","Returned Mileage",getIntegerInstance(),
                          8,222,160);
        form.addTextField("amt","Amount",getCurrencyInstance(),10,10,190);
        form.setEditable("amt",false);
        form.addTextField("msg","Message",45,10,220);
        form.setEditable("msg",false);
        
    };  // setupForm
    
    
    private void fillForm ( Car aCar ) {
        
        form.writeString("licence",aCar.getLicence());
        form.writeInt("oMileage",aCar.getMileage());
        form.writeInt("cat",aCar.getCategory());
        form.writeDouble("rate",aCar.getRate());
        
    };  // fillForm
    
    
    private void addAvail ( Car aCar ) {
        
        avail.toFront();
        while ( ! avail.offEnd() &&
               aCar.getMileage() >= avail.get().getMileage() ) {
            avail.advance();
        };
        avail.add(aCar);
        
    };  // addAvail
    
    
    private Car removeAvail ( int cat ) {
        
        Car   result;  // car being rented
        
        avail.toFront();
        while ( ! avail.offEnd() && avail.get().getCategory() != cat ) {
           avail.advance();
        };
        if ( avail.offEnd() ) {
            result = null;
        }
        else {
            result = avail.remove();
        };
        return result;
        
    };  // removeAvail
    
    
    private void listAvail ( ) {
        
        avail.toFront();
        while ( ! avail.offEnd() ) {
            display.writeString(avail.get().getLicence());
            display.writeInt(avail.get().getMileage());
            display.writeInt(avail.get().getCategory());
            display.newLine();
            avail.advance();
        };
        display.newLine();
        
    };  // listAvail
    
    
    private void addRented ( Car aCar ) {
        
        rented.toFront();
        rented.add(aCar);
        
    };  // addRented
    
    
    private Car removeRented ( String licence ) {
        
        Car   result;  // car being returned
        
        rented.toFront();
        while ( ! rented.offEnd()
                   && rented.get().getLicence().compareTo(licence) != 0 ) {
            rented.advance();
        };
        if ( rented.offEnd() ) {
            result = null;
        }
        else {
            result = rented.remove();
        };
        return result;
        
    }; // removeRented
    
    
    private void listRented ( ) {
        
        rented.toFront();
        while ( ! rented.offEnd() ) {
            display.writeString(rented.get().getLicence());
            display.writeInt(rented.get().getMileage());
            display.writeInt(rented.get().getCategory());
            display.newLine();
            rented.advance();
        };
        display.newLine();
        
    };  // listRented
    
    
    public static void main ( String[] args ) { Rental r = new Rental(); };
    
    
}  // Rental