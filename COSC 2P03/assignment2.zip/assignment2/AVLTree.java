//Xinan Wang.5535802
package assignment2;
import java.util.*;
import static java.lang.Math.*;
public class AVLTree<E extends Comparable<E>> extends BinarySearchTree<E> implements Iterable<E>{
 BinaryNode<E> myTree;
 public AVLTree(){ }
  
  public BinaryNode add(BinaryNode<E> myTree,BinaryNode<E> a){
    if(myTree==null)
      myTree=a;
    else
    {BinaryNode<E> curr=a;
      BinaryNode<E> parent;
      while(true){
        parent=curr;
        if(a.compareTo(curr)<0)
        { curr=curr.left;
          if(curr==null)
          {parent.left=a;
            return balance(curr);
          }
        }
        else
        {curr=curr.right;
          if(curr==null)
          {parent.right=a;
          return balance(curr);}
        }
       
      }
    }
  }  
  
  private static final int ALLOWED_IMBALANCE = 1;

 
  private BinaryNode<E> balance( BinaryNode t )
  {
    if( t == null )
      return t;
    if( height( t.left ) - height( t.right ) > ALLOWED_IMBALANCE )
      if( height( t.left.left ) >= height( t.left.right ) )
      t = rotateWithLeftChild( t );
    else
      t = doubleWithLeftChild( t );
    else
      if( height( t.right ) - height( t.left ) > ALLOWED_IMBALANCE )
      if( height( t.right.right ) >= height( t.right.left ) )
      t = rotateWithRightChild( t );
    else
      t = doubleWithRightChild( t );
    
    t.height = Math.max( height( t.left ), height( t.right ) ) + 1;
    return t;
  }
  private BinaryNode rotateWithLeftChild(BinaryNode k2)
     {
         BinaryNode k1 = k2.left;
        k2.left = k1.right;
         k1.right = k2;
         k2.height = max( height( k2.left ), height( k2.right ) ) + 1;
        k1.height = max( height( k1.left ), k2.height ) + 1;
         return k1;
     }
     private BinaryNode rotateWithRightChild(BinaryNode k1)
    {
        BinaryNode k2 = k1.right;
        k1.right = k2.left;
         k2.left = k1;
         k1.height = max( height( k1.left ), height( k1.right ) ) + 1;
        k2.height = max( height( k2.right ), k1.height ) + 1;
       return k2;
     }
     private BinaryNode doubleWithLeftChild(BinaryNode k3)
     {
         k3.left = rotateWithRightChild( k3.left );
         return rotateWithLeftChild( k3 );
     }
     private BinaryNode doubleWithRightChild(BinaryNode k1)
    {
       k1.right = rotateWithLeftChild( k1.right );
         return rotateWithRightChild( k1 );
    }    
     private int height(BinaryNode T){
       return T=null?-1:T.height;
     }
     private int max(int lhs, int rhs)
     {return lhs>rhs?lhs:rhs;
     }
 /* public void preorder(BinaryNode T){
    if(T == null)
      return;
    else
    {while(T!=null){
      iterator(T);
      if(T.left!=null)
        iterator(T.left);
      else if(T.right!=null)
        iterator(T.right);
      T=T.left;
    }
    }
  }*/
  public void preorder(BinaryNode T){
    if(T==null)
      return;
    else{
    Stack TS;
  while (T!= null)
  {//T.displayNode();
    TS.push(T);
    if(T.right!=null)
      TS.push(T.right);
    if(T.left!=null)
      T=T.left;
    else if(!TS.isEmpty())
    {T=TS.pop();
      }
    else
      T=null;
  }}
  }

  
  public void inorder(BinaryNode T){
    Stack TS;
    if(T == null)
      return;
    else
    {while(T!=null){
      {if(T.right!=null)
      TS.push(T.right);
    else if(T.left!=null)
      T=T.left;}
    TS.push(T);
    if(!TS.isEmpty())
    T=TS.pop();
    else
      T=null;}
    }
  }
  public void iterator(BinaryNode TQ){
    TQ=new BinaryNode(myTree);
    while(TQ!=null)
    {System.out.println(TQ);
      if(TQ.left != null)
        System.out.println(TQ.left);
      if(TQ.right != null)
        System.out.println(TQ.right);
    }
  }
}
