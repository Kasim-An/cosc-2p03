//Xinan Wang.5535802
import java.util.*;
public class AVLTreeTest <E extends Comparable<E>> extends BinarySearchTree<E> implements Iterable<E>
 {
     public static void main(String[] args)
    {            
        Scanner scan = new Scanner(System.in);
        AVLTree avlt = new AVLTree(); 
        System.out.println("AVLTree Tree Test\n");          
       char ch;
        do    
        {
            System.out.println("\nAVLTree Operations\n");
            System.out.println("1. insert ");
            System.out.println("2. preorder");
            System.out.println("3. inorder");
            System.out.println("4. iterator");
            System.out.println("5. clear tree");
            int choice = scan.nextInt();            
            switch (choice)
            {
            case 1 : 
                System.out.println("Enter integer element to insert");
                avlt.insert( scan.nextInt() );                     
                break;                          
            case 2 : 
              System.out.println(avlt.preorder());
              break;                                          
              case 3 : 
                System.out.println(avlt.inorder());
                break;     
            case 4 : 
                System.out.println(iterator());
                break;     
            case 5 : 
                System.out.println("\nTree Cleared");
                avlt.makeEmpty();
                break;         
            default : 
                System.out.println("Wrong Entry \n ");
                break;   
            } 
            System.out.print("\nPre order : ");
            avlt.preorder();
            System.out.print("\nIn order : ");
            avlt.inorder();
            
            System.out.println("continue enter?(Type y or n) \n");
            ch = scan.next().charAt(0);                        
        } while (ch == 'Y'|| ch == 'y');               
     }
}