package UseDates;


import Dates.*;


/** This class is a test harness to test the Dates library including GregorianDate
  * and JulianDate. Note 2016 ia a leap year.
  * 
  * @author  D. Hughes
  * 
  * @version  1.0 (Feb. 2016)                                                    */

public class UseDates {
    
    
    /** This constructor tests the GregorianDate and JulianDate implementations of
      * the Date interface.                                                      */
    
    public UseDates ( ) {
        
        Date  today;  // today's date
        Date  d200;   // day 200 (Julian) or 7/19 (7/18 leap year) (Gregorian)
        Date  leap;   // Feb 29 if a leap year Mar 1 if not
        
        today = new JulianDate();
        d200 = new JulianDate(200);
        leap = new JulianDate(60);
        
        System.out.println(Date.YEAR);
        
        System.out.println(today);
        System.out.println(d200);
        System.out.println(d200.between(today));
        System.out.println(today.compareTo(d200)<0);
        System.out.println(leap);
        
        today = new GregorianDate();
        d200 = new GregorianDate(7,18);
        leap = new GregorianDate(2,29);
        
        System.out.println(today);
        System.out.println(d200);
        System.out.println(d200.between(today));
        System.out.println(today.compareTo(d200)<0);
        System.out.println(leap);
        
        today = new JulianDate();
        d200 = new GregorianDate(7,18);
        
        System.out.println(today);
        System.out.println(d200);
        System.out.println(d200.between(today));
        System.out.println(today.compareTo(d200)<0);
        
        System.out.println(new JulianDate("31/2016"));
        System.out.println(new GregorianDate("31/1/2016"));
        
    };  // constructor
    
    
    public static void main ( String[] args ) { UseDates u = new UseDates(); };
    
    
}  // UseDates