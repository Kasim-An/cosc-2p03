package Dates;


import java.io.*;
import java.util.*;


/** This class defines an implementation of the abstract data type Date
  * representing a date in the current year (2016) using the Julian
  * representation (day/year). Date objects are Serializable and immutable.
  * 
  * @author  D. Hughes
  *
  * @version 1.0 (Feb. 2016)                                                     */

public class JulianDate implements Date, Serializable  {
    
    
    public static final long serialVersionUID = 987650002L;
    private static final int DAYS_IN_YEAR = 366;  // days in year 2016
    
    
    private int dayNum;  // ths day number within the year
    
    
    /** This constructor creates a Julian date object in the current year for the
      * given day number. If the day number does not lie within the valid range an
      * exception will be thrown.
      * 
      * @param  day  day number
      * 
      * @throws  InvalidDateException  if day does not fall within the current
      *                                year.                                     */
    
    public JulianDate ( int day ) {
        
        if ( day < 1 | day > DAYS_IN_YEAR ) {
            throw new InvalidDateException();
        }
        dayNum = day;
        
    };  // constructor
    
    
    /** This constructor creates a Julian date object representing today in the
      * current year.                                                            */
    
    public JulianDate ( ) {
        
        this(Calendar.getInstance().get(Calendar.DAY_OF_YEAR));
        
    };  // constructor
    
    
    /** This constructor creates a Julian date object representing the date
      * specified by the parameter. The format of the string must be day/year each
      * part being an integer. The year must be the current year and the day an
      * integer between 1 &amp; the number of days in the year.
      * 
      * @param  s  the year as a string in format day/year.
      * 
      * @throws  InvalidDateException  if the year or day part is invalid.       */
    
    public JulianDate ( String s ) {
        
        String[]  part;
        int       d;
        
        part = s.split("/");
        if ( ! part[1].equals(YEAR) ) {
            throw new InvalidDateException();
        };
        d = Integer.parseInt(part[0]);
        if ( d < 1 | d > DAYS_IN_YEAR ) {
            throw new InvalidDateException();
        };
        dayNum = d;
        
    };  // constructor
    
    
    /** This method returns the day number within the year (from Jan 1 = 1). It is
      * intended solely for use by implementation classes for interoperability.
      * 
      * @return  int  day number within the year (Jan 1 = 1)                     */
    
    public int getDays ( ) {
        
        return dayNum;
        
    };  // getDays
    
    
    /** This method compares this date object to other. It returns negative it
      * this date precedes the other, zero if they represent tha same date and
      * positive if this date follows the other.
      * 
      * @param  other  other date for comparison
      * 
      * @return  int  &lt;0 if this precedes other, 0 if same date, &gt;0 if this
      *               follows other                                              */
    
    public int compareTo ( Date other ) {
        
        return dayNum - other.getDays();
        
    };  // compareTo
    
    
    /** This method returns the date days following this date for positive days
      * values and the date days predeeding this for negative days values.
      * 
      * @param  days  the number of days to advance. Negative values produce
      *               preceeding dates.
      * 
      * @return  Date  new date before (days&lt;0) or after (days&gt;0) this date.
      *
      * @throws  InvalidDateException  if new date would not be in the current
      *                                year                                      */
    
    public Date advance ( int days ) {
        
        return new JulianDate(dayNum + days);
        
    };  // advance
    
    
    /** This method returns the number of days between this date and other. If
      * other precedes this, the result is negative.
      * 
      * @param  other  the date for difference computation
      * 
      * @return  int  the number of days between this and other (&lt;0 if other
      *               precedes this)                                             */
    
    public int between ( Date other ) {
        
        return dayNum - other.getDays();
        
    };  // between
    
    
    /** This method returns a string representation of this date suitable for
      * display in the format day/year.
      * 
      * @return  String  the string representation of this date.                 */
    
    public String toString ( ) {
        
        return dayNum + "/" + YEAR;
        
    };  // toString
    
    
}  // JulianDate