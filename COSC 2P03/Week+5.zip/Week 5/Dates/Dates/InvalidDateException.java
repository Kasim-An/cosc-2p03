package Dates;


/** This class representats the exception ocurring when an attempt is made to
  * produce a date that is invlaid, specifically if it does not fall within the
  * current year.                                                                */

public class InvalidDateException extends RuntimeException { }