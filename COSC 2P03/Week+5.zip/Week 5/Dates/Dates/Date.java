package Dates;


/** This interface defines an abstract data type representing a date in the current
  * year (2016). Date objects are immutable.
  * 
  * @author  D. Hughes
  *
  * @version 1.0 (Feb. 2016)                                                     */

public interface Date {
    
    
    public static final String YEAR = "2016";  // the year of the date object
    
    
    /** This method returns the day number within the year (from Jan 1 = 1). It is
      * intended solely for use by implementation classes for interoperability.
      * 
      * @return  int  day number within the year (Jan 1 = 1)                     */
    
    public int getDays ( ) ;
    
    
    /** This method compares this date object to other. It returns negative it
      * this date precedes the other, zero if they represent tha same date and
      * positive if this date follows the other.
      * 
      * @param  other  other date for comparison
      * 
      * @return  int  &lt;0 if this precedes other, 0 if same date, &gt;0 if this
      *               follows other                                              */
    
    public int compareTo ( Date other ) ;
    
    
    /** This method returns the date days following this date for positive days
      * values and the date days predeeding this for negative days values.
      * 
      * @param  days  the number of days to advance. Negative values produce
      *               preceeding dates.
      * 
      * @return  Date  new date before (days&lt;0) or after (days&gt;0) this date.
      *
      * @throws  InvalidDateException  if new date would not be in the current
      *                                year                                      */
    
    public Date advance ( int days ) ;
    
    
    /** This method returns the numebr of days between this date and other. If
      * other precedes this, the result is negative.
      * 
      * @param  other  the date for difference computation
      * 
      * @return  int  the number of days between this and other (&lt;0 if other
      *               precedes this)                                             */
    
    public int between ( Date other ) ;
    
    
}  // Date