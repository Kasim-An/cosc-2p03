package Dates;


import java.io.*;
import java.util.*;


/** This class defines an implementation of the abstract data type Date
  * representing a date in the current year (2016) using the Gregorian
  * representation (day/month/year). Date objects are Serializable and immutable.
  * 
  * @author  D. Hughes
  *
  * @version 1.0 (Feb. 2016)                                                     */

public class GregorianDate implements Date, Serializable {
    
    
    public static final long serialVersionUID = 987650001L;
    
    private static final int FEB = 29;  // days in February in 2016
    private static final int[] DAYS_IN_MONTH =
                                          {0,31,FEB,31,30,31,30,31,31,30,31,30,31};
                                        // days in each month
    
    
    private int  month;  // month number
    private int  day;    // day in month
    
    
    /** This constructor creates a Gregorian date object in the current year for
      * the given month and day. If possible, the constructor will adjust the month
      * and day numbers to lie within the valid range. If not, an exception will be
      * thrown.
      * 
      * @param  m  month number
      * @param  d  day number
      * 
      * @throws  InvalidDateException  if m &amp; d cannot be adjusted to fall
      *                                within the current year.                  */
    
    public GregorianDate ( int m, int d ) {
        
        if ( m < 1 ) {
            throw new InvalidDateException();
        };
        while ( m >= 1 & d < 1 ) {
            m = m - 1;
            d = d + DAYS_IN_MONTH[m];
        };
        while ( m <= 12 && d > DAYS_IN_MONTH[m] ) {
            d = d - DAYS_IN_MONTH[m];
            m = m + 1;
        };
        if ( m < 1 | m > 12 ) {
            throw new InvalidDateException();
        };
        month = m;
        day = d;
        
    };  // constructor
    
    
    /** This constructor creates a Gregorian date object representing today in the
      * current year.                                                            */
    
    public GregorianDate ( ) {
        
        this(Calendar.getInstance().get(Calendar.MONTH)+1,
             Calendar.getInstance().get(Calendar.DAY_OF_MONTH));
        
    };  // constructor
    
    
    /** This constructor creates a Gregorian date object representing the date
      * specified by the parameter. The format of the string must be day/month/year
      * each part being an integer. The year must be the current year, the month an
      * integer between 1 &amp; 12 and the day between 1 and the number of days in
      * the month.
      * 
      * @param  s  the year as a string in format day/month/year.
      * 
      * @throws  InvalidDateException  if the year, month or day part is invalid.*/
    
    public GregorianDate ( String s ) {
        
        String[]  part;
        int       m, d;
        
        part = s.split("/");
        if ( ! part[2].equals(YEAR) ) {
            throw new InvalidDateException();
        };
        m = Integer.parseInt(part[1]);
        if ( m < 1 | m > 12 ) {
            throw new InvalidDateException();
        };
        d = Integer.parseInt(part[0]);
        if ( d < 1 | d > DAYS_IN_MONTH[m] ) {
            throw new InvalidDateException();
        };
        month = m;
        day = d;
        
    };  // constructor
    
    
    /** This method returns the day number within the year (from Jan 1 = 1). It is
      * intended solely for use by implementation classes for interoperability.
      * 
      * @return  int  day number within the year (Jan 1 = 1)                     */
    
    public int getDays ( ) {
        
        int num;
        
        num = 0;
        for ( int i=0 ; i<month ; i++ ) {
            num = num + DAYS_IN_MONTH[i];
        };
        num = num + day;
        return num;
        
    };  // getDays
    
    
    /** This method compares this date object to other. It returns negative it
      * this date precedes the other, zero if they represent tha same date and
      * positive if this date follows the other.
      * 
      * @param  other  other date for comparison
      * 
      * @return  int  &lt;0 if this precedes other, 0 if same date, &gt;0 if this
      *               follows other                                              */
    
    public int compareTo ( Date other ) {
        
        return getDays() - other.getDays();
        
    };  // compareTo
    
    
    /** This method returns the date days following this date for positive days
      * values and the date days predeeding this for negative days values.
      * 
      * @param  days  the number of days to advance. Negative values produce
      *               preceeding dates.
      * 
      * @return  Date  new date before (days&lt;0) or after (days&gt;0) this date.
      *
      * @throws  InvalidDateException  if new date would not be in the current
      *                                year                                      */
    
    public Date advance ( int days ) {
        
        return new GregorianDate(month,day+days);
        
    };  // advance
    
    
    /** This method returns the numebr of days between this date and other. If
      * other precedes this, the result is negative.
      * 
      * @param  other  the date for difference computation
      * 
      * @return  int  the number of days between this and other (&lt;0 if other
      *               precedes this)                                             */
    
    public int between ( Date other ) {
        
        return getDays() - other.getDays();
        
    };  // between
        
    
    /** This method returns a string representation of this date suitable for
      * display in the format day/month/year.
      * 
      * @return  String  the string representation of this date.                 */
    
    public String toString ( ) {
        
        return day + "/" + month + "/" + YEAR;
        
    };  // toString
    
    
}  // GregorianDate