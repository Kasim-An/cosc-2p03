package Assign_2;
import java.util.*;
import static java.lang.Math.*;


public class AVLTree<E extends Comparable<E>> extends BinarySearchTree<E>{
  BinaryNode<E> T;
 
  public AVLTree(){
    
  }
  
  public void add( BinaryNode<E> newNode) { 
    if(T == null)
      T = newNode;
    else if(newNode.info.compareTo( T.info)>0)// insert in left subtree 
      
    { 
      T=T.left;
      add( newNode);
      T.left = newNode;
      if(height(T.left) -height(T.right) == 2) 
        if(newNode.info.compareTo(T.left.info)<0)//left subtree of T.left
        T = rotateWithLeftChild(T);
      else//right subtree of T.left 
          T = doubleWithLeftChild(T); }
    else // insert in right subtree 
    { 
      T = T.right;
      add( newNode);
      T.right = newNode;
      if(height(T.right) -height(T.left) == 2) 
        if(newNode.info.compareTo( T.right.info)>0)// right subtree of T.right 
        T = rotateWithRightChild(T); 
      else// left subtree of T.right 
        T = doubleWithRightChild(T); }
    T.height = max(height(T.left), height(T.right)) + 1; 
   
  }
  public   int height(BinaryNode<E> T) {
    return T == null? -1 : T.height; 
  }
  
  private  BinaryNode<E> rotateWithLeftChild( BinaryNode<E> k2 ){
    BinaryNode<E> k1 = k2.left;
    k2.left = k1.right;
    k1.right = k2;
    k2.height = max( height( k2.left ), height( k2.right ) ) + 1;
    k1.height = max( height( k1.left ), k2.height ) + 1;
    return k1;
  }
  
  private BinaryNode<E> rotateWithRightChild( BinaryNode<E> k1 ){
    BinaryNode<E> k2 = k1.right;
    k1.right = k2.left;
    k2.left = k1;
    k1.height = max( height( k1.left ), height( k1.right ) ) + 1;
    k2.height = max( height( k2.right ), k1.height ) + 1;
    return k2;
  }

  private  BinaryNode<E> doubleWithLeftChild( BinaryNode<E> k3 ){
    k3.left = rotateWithRightChild( k3.left );
    return rotateWithLeftChild( k3 );
  }
  
  private BinaryNode<E> doubleWithRightChild( BinaryNode<E> k1 ){
    k1.right = rotateWithLeftChild( k1.right );
    return rotateWithRightChild( k1 );
  }

}