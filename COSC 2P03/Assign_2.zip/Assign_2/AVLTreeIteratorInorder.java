package Assign_2;
import java.util.*;

public class AVLTreeIteratorInorder<E extends Comparable<E>> implements Iterator<E>{
  LinkedList<BinaryNode<E>> queue;
  BinaryNode<E> nextNode;
  public  AVLTreeIteratorInorder(BinaryNode<E> tree){
    queue=new LinkedList<BinaryNode<E>>();
    if (nextNode!=null) 
      queue.add(tree);
  }
  
 public boolean hasNext() {
  return !(nextNode==null);
 }
 
 public E next() {
   E forReturn;
   if (nextNode == null)
     throw new NoSuchElementException();
   BinaryNode<E> currentNode = nextNode;
   forReturn = nextNode.info;
   if(nextNode!=null){
     while (nextNode.left!= null){
       nextNode = nextNode.left;
     }
     forReturn = nextNode.info;
     queue.add(nextNode);
     
   }
   else if(nextNode.left == null){
     forReturn = nextNode.info;
     queue.add(nextNode);    
   }
   else if (nextNode.right!= null){
     while (nextNode.right.left!= null){
       nextNode = nextNode.left;
     }
     forReturn = nextNode.info;
     queue.add(nextNode);   
   }
   else 
     throw new NoSuchElementException();
   return forReturn;    
 } 
   
   public void remove() {
     throw new UnsupportedOperationException();
   }
}
