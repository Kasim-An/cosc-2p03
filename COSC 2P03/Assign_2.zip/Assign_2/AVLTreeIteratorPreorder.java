package Assign_2;
import java.util.*;

public class AVLTreeIteratorPreorder<E extends Comparable<E>> implements Iterator<E>{
   LinkedList<BinaryNode<E>> queue; 
   BinaryNode<E> nextNode;
   public  AVLTreeIteratorPreorder(BinaryNode<E> tree){
     queue=new LinkedList<BinaryNode<E>>();
     if (tree!=null) {
       queue.add(tree);
     }
   }
   //If there are still nodes on the queue, then there are more elements
   public boolean hasNext() {
     return !(nextNode==null);
   } 
   
   public E next() {
     E forReturn;
     if (nextNode == null)
       throw new NoSuchElementException();
     BinaryNode<E> currentNode = nextNode;
     forReturn = currentNode.info;     
     if (nextNode.left!= null){
       nextNode = nextNode.left;
       queue.add(nextNode);
     }
     
     else if (nextNode.right!= null){
       nextNode = nextNode.right;
       queue.add(nextNode);
     }
     else {
       BinaryNode<E> parent = nextNode.parent;
       BinaryNode<E> child = nextNode;
       while (parent != null
                && (parent.right == child || parent.right == null)) {
         child = parent;
         parent = parent.parent;
     }
       if (parent == null){
       nextNode = null; 
       queue.add(nextNode);
       }
       else{
       nextNode = parent.right;
       queue.add(nextNode);
       }
     }
     return forReturn;
   } 
   
   public void remove() {
     throw new UnsupportedOperationException();
   }
}


