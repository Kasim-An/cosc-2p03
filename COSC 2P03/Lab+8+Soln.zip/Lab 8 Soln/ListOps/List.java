package ListOps;


class List {
    
    int   head;
    List  tail;
    
    List ( int h, List t ) {
        head = h;
        tail = t;
    };
    
}  //List