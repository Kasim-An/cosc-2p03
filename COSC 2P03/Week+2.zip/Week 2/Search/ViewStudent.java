package Search;

import BasicIO.*;


/** This class is a program to alow student's final marks to be viewed.
  * 
  * @see Student
  *
  * @author D. Hughes
  *
  * @version 1.0 (Mar. 2014)                                                     */

public class ViewStudent {
    
    
    private Student[]       theClass;  // students in course
    private ASCIIPrompter   prompt;    // prompter for student number
    private ASCIIDisplayer  display;   // display for student mark
    
    /** The constructor loads the students, prompts for student number and displays
      * selected student information.                                            */
    
    public ViewStudent ( ) {
        
        ASCIIDataFile   gradeList;  // the grade list file
        String          stNum;      // student number to display
        Student         aStd;       // student to display
                
        gradeList = new ASCIIDataFile();
        loadStudents(gradeList);
        gradeList.close();
        prompt = new ASCIIPrompter();
        prompt.setLabel("ST #");
        display = new ASCIIDisplayer();
        for ( ; ; ) {
            stNum = prompt.readString();
        if ( prompt.isEOF() ) break;
            aStd = search(stNum);
            if ( aStd != null ) {
                displayStd(aStd);
            }
            else {
                display.writeString(stNum+" not found"); display.newLine();
                display.newLine();
            };
        };
        display.close();
        
    }; // constructor
    
    
    private void loadStudents ( ASCIIDataFile classList ) {
        
        int  numStd;
        
        numStd = classList.readInt();
        theClass = new Student[numStd];
        for ( int i=0 ; i<numStd ; i++ ) {
            theClass[i] = new Student(classList);
        };
        classList.close();
        
    };  // loadStudents
    
    
    private void displayStd ( Student aStd ) {
        
        display.writeString("St #:  "+aStd.getStNum()); display.newLine();
        display.writeString("Name:  "+aStd.getName()); display.newLine();
        display.writeString("Grade: "+aStd.getFinalGrade()); display.newLine();
        display.newLine();
        
    };  // displayStd
    
    
    /** This method locates the student with a particular student number within
      * the class array using sequential search.
      * 
      * @param  stNum  the student number to search for
      * @return Student  the student (null if not found).                        */
    
    private Student search ( String stNum ) {
        
        Student  result;
        
        result = null;
        for ( int i=0 ; i<theClass.length ; i++ ) {
        if ( theClass[i].getStNum().equals(stNum) )
                                                  { result = theClass[i]; break; };
        };
        return result;
        
    };  // search 
    
    
    /** This method locates the student with a particular student number within
      * the class array using binary search.
      * 
      * @param  stNum  the student number to search for
      * @return Student  the student (null if not found).                        */
    
/*  private Student search ( String stNum ) {
        
        Student  result;  // Widget found
        int     lo;       // low end of bound
        int     hi;       // high end of bound
        int     pos;      // probe position
        
        result = null;
        lo = 0;
        hi = theClass.length - 1;
        while ( lo <= hi ) {
            pos = (lo + hi) / 2;
        if ( stNum.compareTo(theClass[pos].getStNum()) == 0 )
                                                { result = theClass[pos]; break; };
            if ( stNum.compareTo(theClass[pos].getStNum()) > 0 ) {
                lo = pos + 1;
            }
            else {
                hi = pos - 1;
            };
        };
        return result;
        
    }; // search */
    
    
    public static void main ( String[] args ) { ViewStudent v = new ViewStudent(); };
    
    
} // ViewStudent