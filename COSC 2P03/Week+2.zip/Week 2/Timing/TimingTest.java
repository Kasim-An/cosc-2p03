package Timing;


import BasicIO.*;


/** This class is a program to do a timing test of an algorithm. It uses the
  * currentTimeMillis method of the System object to find the current time before
  * and after the algorithm is executed, to determine the elapsed time.
  *
  * @author D. Hughes
  *
  * @version 1.0 (Jan 2014)                                                      */

public class TimingTest {
    
    
    private static final int  NUM_TESTS = 50;  // number of calls to time
    private static final int  SIZE = 20;       // small problem size (n)
    private static final int  FACTOR = 2;      // problem size increase factor
    private static final long DELAY = 1;       // delay size
    
    private ASCIIDisplayer out;  // displayer for results
    
    
    /** The constructor does timing tests of 4 methods representing sublinear,
      * linear, superlinear and quadratic algorithms. It executes each method a
      * number of times (NUM_TESTS) for each of two problem sizes (SIZE and
      * FACTOR*SIZE) using a delay of DELAY miliseconds as the unit operation
      * size.                                                                    */
    
    public TimingTest ( ) {
        
        long t1;   // time before execution
        long t2;   // time after execution

        out = new ASCIIDisplayer();
        out.writeString("Timing test of methods for");
        out.writeInt(NUM_TESTS);
        out.writeString("calls with delay of");
        out.writeLong(DELAY);
        out.writeString("ms");
        out.newLine();
        out.newLine();
        out.writeString("  n  O(lg n)    O(n)  O(nlgn)  O(n^2)");
        out.newLine();
        out.writeInt(SIZE,3);
        t1 = System.currentTimeMillis();
        for ( int i=1 ; i<=NUM_TESTS ; i++ ) {
            lgNMethod(SIZE);
        };
        t2 = System.currentTimeMillis();
        out.writeLong(t2-t1,8);
        t1 = System.currentTimeMillis();
        for ( int i=1 ; i<=NUM_TESTS ; i++ ) {
            linearMethod(SIZE);
        };
        t2 = System.currentTimeMillis();
        out.writeLong(t2-t1,7);
        t1 = System.currentTimeMillis();
        for ( int i=1 ; i<=NUM_TESTS ; i++ ) {
            nLgNMethod(SIZE);
        };
        t2 = System.currentTimeMillis();
        out.writeLong(t2-t1,8);
        t1 = System.currentTimeMillis();
        for ( int i=1 ; i<=NUM_TESTS ; i++ ) {
            quadraticMethod(SIZE);
        };
        t2 = System.currentTimeMillis();
        out.writeLong(t2-t1,7);
        out.newLine();
        out.writeInt(SIZE*FACTOR,3);
        t1 = System.currentTimeMillis();
        for ( int i=1 ; i<=NUM_TESTS ; i++ ) {
            lgNMethod(SIZE*FACTOR);
        };
        t2 = System.currentTimeMillis();
        out.writeLong(t2-t1,8);
        t1 = System.currentTimeMillis();
        for ( int i=1 ; i<=NUM_TESTS ; i++ ) {
            linearMethod(SIZE*FACTOR);
        };
        t2 = System.currentTimeMillis();
        out.writeLong(t2-t1,7);
        t1 = System.currentTimeMillis();
        for ( int i=1 ; i<=NUM_TESTS ; i++ ) {
            nLgNMethod(SIZE*FACTOR);
        };
        t2 = System.currentTimeMillis();
        out.writeLong(t2-t1,8);
        t1 = System.currentTimeMillis();
        for ( int i=1 ; i<=NUM_TESTS ; i++ ) {
            quadraticMethod(SIZE*FACTOR);
        };
        t2 = System.currentTimeMillis();
        out.writeLong(t2-t1,7);
        out.newLine();
        out.close();
        
    }; // constructor
    
    
    /** This method represents an algorithm with sublinear order (O(lg n)).
      *
      * @param n problem size.                                                   */
    
    private void lgNMethod ( int n ) {
        
        int  i;
        
        for ( i=1 ; i<=n ; i=i*2 ) {
            try { Thread.sleep(DELAY); } catch ( InterruptedException e ) { };
        };
        
    }; // lgNMethod
    
    
    /** This method represents an algorithm with linear order (O(n)).
      *
      * @param n problem size.                                                   */
    
    private void linearMethod ( int n ) {
        
        int  i;
        
        for ( i=1 ; i<=n ; i++ ) {
            try { Thread.sleep(DELAY); } catch ( InterruptedException e ) { };
        };
        
    }; // linearMethod
    
    
    /** This method represents an algorithm with superlinear order (O(n lg n)).
      *
      * @param n problem size.                                                  */
    
    private void nLgNMethod ( int n ) {
        
        int  i, j;
        
        for ( i=1 ; i<=n ; i++ ) {
            for ( j=1 ; j<=n ; j=j*2 ) {
                try { Thread.sleep(DELAY); } catch ( InterruptedException e ) { };
            };
        };
        
    }; // nLgNMethod
    
    
    /** This method represents an algorithm with quadratic order (O(n^2)).
      *
      * @param n problem size.                                                  */
    
    private void quadraticMethod ( int n ) {
        
        int  i, j;
        
        for ( i=1 ; i<=n ; i++ ) {
            for ( j=1 ; j<=n ; j++ ) {
                try { Thread.sleep(DELAY); } catch ( InterruptedException e ) { };
            };
        };
        
    }; // quadraticMethod
    
    
    public static void main ( String args[] ) { TimingTest t = new TimingTest(); };
    
    
} // TimingTest